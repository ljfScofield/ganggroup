#!/usr/env python
# -*- coding: utf-8 -*-

"""
    该模块提供连接数据中心服务器，获取个性化数据、订单信息的API
    This module provides APIs to get personalization data from Data Center.


    __author__ = "XH Smart Card Co,.Ltd. http://www.china-xinghan.com/smartcard/en/"
    __date__ = "Aug 2016"
    __version__ = "0.1.0"

    Copyright 2016 XH Smart Card Co,. Ltd

    Author: wg@china-xinghan.com
"""

import api_util




if __name__ == '__main__':
    pass


