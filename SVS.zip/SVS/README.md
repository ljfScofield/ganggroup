# XHSVS Client

http://www.china-xinghan.com

(C) 2016 Zhuhai XH Smartcard Co., Ltd
